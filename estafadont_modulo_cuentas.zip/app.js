// CONFIGURACIÓN: crea un proyecto en https://supabase.com y pega aquí sus datos.
const SUPABASE_URL = "PEGA_AQUI_TU_SUPABASE_URL";
const SUPABASE_ANON_KEY = "PEGA_AQUI_TU_SUPABASE_ANON_KEY";

const configured = SUPABASE_URL.startsWith("https://") && SUPABASE_ANON_KEY.length > 20;
const supabaseClient = configured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

const $ = (id) => document.getElementById(id);
let mode = "login";
let currentUser = null;
let profile = null;
let quizAnswered = false;

const achievements = [
  { code:"first_steps", icon:"✦", name:"Primeros pasos", desc:"Completa tu primer reto de prevención." },
  { code:"alert_eye", icon:"◉", name:"Ojo alerta", desc:"Aprende a reconocer señales de riesgo." },
  { code:"informed", icon:"◆", name:"Consumidor informado", desc:"Consulta contenidos sobre tus derechos." },
  { code:"digital_guardian", icon:"⬡", name:"Guardián digital", desc:"Completa todas las actividades disponibles." }
];

function showMessage(text, type="info") {
  const box = $("authMessage");
  box.textContent = text;
  box.className = `message show ${type}`;
}
function clearMessage() {
  $("authMessage").textContent = "";
  $("authMessage").className = "message";
}
function setMode(next) {
  mode = next;
  clearMessage();
  const registering = mode === "register";
  $("loginTab").classList.toggle("active", !registering);
  $("registerTab").classList.toggle("active", registering);
  $("loginTab").setAttribute("aria-selected", String(!registering));
  $("registerTab").setAttribute("aria-selected", String(registering));
  $("nameField").classList.toggle("hidden", !registering);
  $("confirmField").classList.toggle("hidden", !registering);
  $("password").autocomplete = registering ? "new-password" : "current-password";
  $("passwordHint").textContent = registering ? "Mínimo 8 caracteres" : " ";
  $("submitAuth").innerHTML = registering ? 'Crear cuenta <span>→</span>' : 'Iniciar sesión <span>→</span>';
  $("authTitle")?.focus?.();
}
function showAuth() {
  $("authView").classList.remove("hidden");
  $("dashboardView").classList.add("hidden");
}
function showDashboard() {
  $("authView").classList.add("hidden");
  $("dashboardView").classList.remove("hidden");
  renderProfile();
  loadAchievements();
}
function initials(name) {
  return (name || "ED").trim().split(/\s+/).slice(0,2).map(x => x[0]?.toUpperCase() || "").join("") || "ED";
}
function renderProfile() {
  const name = profile?.display_name || currentUser?.user_metadata?.display_name || currentUser?.email?.split("@")[0] || "Consumidor";
  $("welcomeName").textContent = name.split(" ")[0];
  $("profileName").textContent = name;
  $("profileEmail").textContent = currentUser?.email || "";
  $("avatarInitials").textContent = initials(name);
  $("editName").value = name;
}
async function handleAuth(event) {
  event.preventDefault();
  clearMessage();
  if (!supabaseClient) {
    showMessage("La interfaz está lista, pero falta conectar Supabase. Configura la URL y la clave pública en app.js para activar las cuentas reales.", "info");
    return;
  }
  const email = $("email").value.trim();
  const password = $("password").value;
  const displayName = $("displayName").value.trim();
  if (password.length < 8) return showMessage("La contraseña debe tener al menos 8 caracteres.", "error");
  if (mode === "register") {
    if (!displayName) return showMessage("Escribe el nombre que aparecerá en tu perfil.", "error");
    if (password !== $("confirmPassword").value) return showMessage("Las contraseñas no coinciden.", "error");
    const { data, error } = await supabaseClient.auth.signUp({
      email, password, options: { data: { display_name: displayName } }
    });
    if (error) return showMessage(error.message, "error");
    if (data.session) {
      currentUser = data.user;
      await ensureProfile();
      showDashboard();
    } else {
      showMessage("¡Registro iniciado! Revisa tu correo para confirmar la cuenta y después inicia sesión.", "success");
      setMode("login");
    }
  } else {
    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
    if (error) return showMessage("No pudimos iniciar sesión. Revisa tu correo y contraseña.", "error");
    currentUser = data.user;
    await ensureProfile();
    showDashboard();
  }
}
async function signInGoogle() {
  if (!supabaseClient) {
    showMessage("Para activar Google, primero conecta Supabase y habilita Google como proveedor de acceso.", "info");
    return;
  }
  const { error } = await supabaseClient.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: window.location.origin + window.location.pathname }
  });
  if (error) showMessage(error.message, "error");
}
async function ensureProfile() {
  if (!currentUser) return;
  const name = currentUser.user_metadata?.display_name || currentUser.email?.split("@")[0] || "Consumidor";
  const { data, error } = await supabaseClient.from("profiles")
    .upsert({ id: currentUser.id, display_name: name }, { onConflict: "id" })
    .select().single();
  if (!error) profile = data;
  else profile = { display_name: name, points: 0, challenges_completed: 0 };
}
async function loadAchievements() {
  if (!currentUser || !supabaseClient) return;
  const { data: p } = await supabaseClient.from("profiles")
    .select("*").eq("id", currentUser.id).maybeSingle();
  if (p) profile = p;
  const { data: earned } = await supabaseClient.from("user_achievements")
    .select("achievement_code").eq("user_id", currentUser.id);
  renderAchievements((earned || []).map(x => x.achievement_code));
}
function renderAchievements(earned=[]) {
  const unlocked = new Set(earned);
  $("badgeGrid").innerHTML = achievements.map(item => `
    <article class="achievement ${unlocked.has(item.code) ? "unlocked" : ""}">
      <div class="medal">${item.icon}</div>
      <h3>${item.name}</h3><p>${item.desc}</p>
      <span class="status">${unlocked.has(item.code) ? "✓ DESBLOQUEADA" : "◇ POR CONSEGUIR"}</span>
    </article>`).join("");
  $("badgeCount").textContent = `${unlocked.size}/4`;
  $("pointsValue").textContent = profile?.points || 0;
  $("challengeCount").textContent = profile?.challenges_completed || 0;
}
async function awardFirstChallenge() {
  if (!currentUser || !supabaseClient || quizAnswered) return;
  quizAnswered = true;
  const feedback = $("quizFeedback");
  const { data: existing } = await supabaseClient.from("user_achievements")
    .select("id").eq("user_id", currentUser.id).eq("achievement_code", "first_steps").maybeSingle();
  if (!existing) {
    const { error: insertError } = await supabaseClient.from("user_achievements")
      .insert({ user_id: currentUser.id, achievement_code: "first_steps" });
    if (insertError) {
      feedback.textContent = "Respuesta correcta. Para guardar el logro, revisa la configuración de la base de datos.";
      return;
    }
    const { data: updated, error } = await supabaseClient.from("profiles")
      .update({ points: (profile?.points || 0) + 20, challenges_completed: (profile?.challenges_completed || 0) + 1 })
      .eq("id", currentUser.id).select().single();
    if (!error) profile = updated;
  }
  feedback.textContent = "¡Correcto! Investigar el comercio, comparar precios y revisar el método de pago reduce riesgos. Has desbloqueado tu primera insignia.";
  await loadAchievements();
  document.querySelectorAll(".quiz-option").forEach(btn => btn.disabled = true);
}
async function saveProfile(event) {
  event.preventDefault();
  const newName = $("editName").value.trim();
  if (!newName) return;
  if (!supabaseClient || !currentUser) return;
  const { error: authError } = await supabaseClient.auth.updateUser({ data: { display_name: newName } });
  if (authError) return alert("No se pudo actualizar el nombre. Intenta nuevamente.");
  const { data, error } = await supabaseClient.from("profiles")
    .update({ display_name: newName }).eq("id", currentUser.id).select().single();
  if (error) return alert("No se pudo guardar el perfil. Revisa la conexión.");
  profile = data;
  renderProfile();
  $("profileDialog").close();
}
async function signOut() {
  if (supabaseClient) await supabaseClient.auth.signOut();
  currentUser = null; profile = null; quizAnswered = false;
  $("quizFeedback").textContent = "";
  document.querySelectorAll(".quiz-option").forEach(btn => btn.disabled = false);
  showAuth();
}
async function init() {
  $("loginTab").addEventListener("click", () => setMode("login"));
  $("registerTab").addEventListener("click", () => setMode("register"));
  $("authForm").addEventListener("submit", handleAuth);
  $("googleBtn").addEventListener("click", signInGoogle);
  $("headerAccountBtn").addEventListener("click", () => currentUser ? showDashboard() : showAuth());
  $("logoutBtn").addEventListener("click", signOut);
  $("editProfileBtn").addEventListener("click", () => $("profileDialog").showModal());
  $("profileForm").addEventListener("submit", saveProfile);
  document.querySelectorAll(".quiz-option").forEach(btn => btn.addEventListener("click", () => {
    if (btn.dataset.answer === "b") awardFirstChallenge();
    else $("quizFeedback").textContent = "No exactamente. Antes de pagar, investiga el comercio y evita decidir bajo presión.";
  }));
  renderAchievements([]);
  if (!supabaseClient) return;
  const { data: { session } } = await supabaseClient.auth.getSession();
  if (session?.user) {
    currentUser = session.user;
    await ensureProfile();
    showDashboard();
  }
  supabaseClient.auth.onAuthStateChange(async (_event, sessionNow) => {
    if (sessionNow?.user) {
      currentUser = sessionNow.user;
      await ensureProfile();
      showDashboard();
    } else if (!sessionNow && currentUser) {
      currentUser = null; profile = null; showAuth();
    }
  });
}
document.addEventListener("DOMContentLoaded", init);

# Estafad’ont — módulo de cuentas

Incluye:
- Registro e inicio de sesión con correo y contraseña.
- Acceso con Google mediante Supabase OAuth.
- Perfil personal editable.
- Panel con puntos, retos e insignias.
- Diseño adaptable a móvil y escritorio.

## 1. Crear el proyecto de autenticación
1. Crea un proyecto en https://supabase.com.
2. En Authentication > Providers, activa Email.
3. Activa Google si usarán ese método y configura las credenciales OAuth siguiendo la guía de Supabase.
4. En Authentication > URL Configuration, agrega el dominio donde publicarás la web y la URL de redirección correspondiente.
5. En Project Settings > API copia Project URL y la clave `anon` / publishable. Nunca uses `service_role` en el navegador.

## 2. Crear las tablas
Abre SQL Editor en Supabase, pega el contenido de `supabase.sql` y ejecútalo.

## 3. Conectar el sitio
Abre `app.js` y sustituye:
- `PEGA_AQUI_TU_SUPABASE_URL`
- `PEGA_AQUI_TU_SUPABASE_ANON_KEY`

por los valores de tu proyecto.

## 4. Publicar y probar
Sube `index.html`, `styles.css`, `app.js` y `supabase.sql` a tu proyecto de hosting.
Prueba registro por correo, confirmación de correo, inicio de sesión, Google OAuth, edición del perfil y cierre de sesión.

## Notas de seguridad y alcance
- No se guardan contraseñas en localStorage ni en archivos propios: Supabase Auth administra la autenticación.
- La clave pública `anon` está diseñada para usarse en el navegador con políticas RLS activadas. Nunca publiques la clave `service_role`.
- Las insignias de esta versión son una demostración educativa. Para una plataforma comercial, los puntos y logros deben otorgarse desde funciones del servidor con validación para impedir que el navegador los falsifique.
- Configura un aviso de privacidad real antes de recopilar datos personales. Solicita solo los datos necesarios.
- La interfaz no procesa pagos ni solicita datos bancarios.

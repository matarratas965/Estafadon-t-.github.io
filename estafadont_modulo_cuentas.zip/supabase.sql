-- Ejecuta este SQL en Supabase > SQL Editor.
-- Las políticas RLS aseguran que cada persona solo pueda consultar/modificar su perfil y sus logros.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Consumidor',
  points integer not null default 0 check (points >= 0),
  challenges_completed integer not null default 0 check (challenges_completed >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.user_achievements (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_code text not null,
  earned_at timestamptz not null default now(),
  constraint one_achievement_per_user unique (user_id, achievement_code),
  constraint valid_achievement_code check (
    achievement_code in ('first_steps', 'alert_eye', 'informed', 'digital_guardian')
  )
);

alter table public.profiles enable row level security;
alter table public.user_achievements enable row level security;

drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile"
on public.profiles for select to authenticated
using (auth.uid() = id);

drop policy if exists "Users can insert own profile" on public.profiles;
create policy "Users can insert own profile"
on public.profiles for insert to authenticated
with check (auth.uid() = id);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
on public.profiles for update to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "Users can view own achievements" on public.user_achievements;
create policy "Users can view own achievements"
on public.user_achievements for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can earn own achievements" on public.user_achievements;
create policy "Users can earn own achievements"
on public.user_achievements for insert to authenticated
with check (auth.uid() = user_id);

-- Crear automáticamente el perfil al registrarse.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
